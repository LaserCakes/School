// Steven Romeiro
// U16803837
// Homework 2
// COP 3331

#include <iostream>
#include <stdlib.h>
#include "SavingsAccount.h" 
#include "CheckingAccount.h"

using namespace std;

int main()
{
  SavingsAccount mySavings(2000, 7.0);
  cout << "Savings balance is: " << mySavings.CalculateInterest() << endl;

  CheckingAccount myChecking(2000, 100);
  cout << "Checking balance is: " << myChecking.GetBalance() << endl;


  return 0;
}
